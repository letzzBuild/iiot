self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "bcf017f0123280599f9ba778f7828719",
    "url": "/index.html"
  },
  {
    "revision": "b99f4c6152d80ef1c99b",
    "url": "/static/css/2.1781c263.chunk.css"
  },
  {
    "revision": "22ea99c1c6a0419175cb",
    "url": "/static/css/main.2acde7bb.chunk.css"
  },
  {
    "revision": "b99f4c6152d80ef1c99b",
    "url": "/static/js/2.e52f8582.chunk.js"
  },
  {
    "revision": "f6fbba662f73f9f851c1be155add02a8",
    "url": "/static/js/2.e52f8582.chunk.js.LICENSE.txt"
  },
  {
    "revision": "22ea99c1c6a0419175cb",
    "url": "/static/js/main.b9bc1830.chunk.js"
  },
  {
    "revision": "bccb43675d339c2b2a73",
    "url": "/static/js/runtime-main.48fe03d4.js"
  },
  {
    "revision": "22b3170c9e556fd13a1eb8f012a5635d",
    "url": "/static/media/Acme-Regular.22b3170c.ttf"
  },
  {
    "revision": "76c145c2f3f1c17fd11ec9a3740521f6",
    "url": "/static/media/DancingScript-Bold.76c145c2.ttf"
  },
  {
    "revision": "ae186212bc5c7cc7a85020ca15579e8d",
    "url": "/static/media/Knewave-Regular.ae186212.ttf"
  },
  {
    "revision": "c97a9fc29652bb4afcdac68020e5d0f7",
    "url": "/static/media/Merriweather-Regular.c97a9fc2.ttf"
  }
]);